<template lang="pug">
.app
  img(
    :src="imgSrc"
    :width="imgWidth"
    :height="imgHeight"
  )
</template>

<script>
import { ipcRenderer } from 'electron'

import getSource from './assets/js/getSource'
import getDisplay from './assets/js/getDisplay'
import Kss from './kss'

export default {
  name: 'App',
  components: {

  },
  data () {
    return {
      display: getDisplay(),
      source: null,
      rect: { x1: 0, y1: 0, x2: 0, y2: 0 },
      imgSrc: '',
      imgWidth: 0,
      imgHeight: 0,
      shot: null
    }
  },
  computed: {
    bounds () {
      return {
        x: this.display.x,
        y: this.display.y,
        width: this.display.width,
        height: this.display.height
      }
    },
    width () {
      return this.bounds.width
    },
    height () {
      return this.bounds.height
    }
  },
  mounted () {
    this.init()
  },
  destroyed () {
  },
  methods: {
    async init () {
      this.source = await getSource(this.display)
      console.log(this.source)
      if (this.source) {
        this.imgSrc = this.source.thumbnail.toDataURL()
        this.imgWidth = this.source.width
        this.imgHeight = this.source.height
        this.$nextTick(() => {
        this.shot = new Kss(
        {
          key:{
            url:this.imgSrc,
            height:this.imgHeight,
            width:this.imgWidth
          },
          endCB: (data) => {
            this.done(data)
          },
          immediately: true
          }
        )
        this.show()
      })
      }
    },
    show () {
      ipcRenderer.send('ShortcutCapture::SHOW', this.bounds)
    },
    hide () {
      ipcRenderer.send('ShortcutCapture::HIDE', this.bounds)
    },
    cancel () {
      this.hide()
    },
    done (dataUrl) {
      ipcRenderer.send('ShortcutCapture::CAPTURE', dataUrl)
      this.hide()
    }
  }
}
</script>

<style lang="scss" scoped>
  $baseColor: #488ff9;
  * {
      box-sizing: border-box;
    }
    html,
    body,
    .app {
        margin:0;
        padding: 0;
      user-select: none;
      overflow: hidden;
    }
    .app {
      position: absolute;
      top: 0;
      right: 0;
      bottom: 0;
      left: 0;
      cursor: crosshair;
    }
</style>
